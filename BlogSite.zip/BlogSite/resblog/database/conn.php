<?php
//database connection
($GLOBALS["___mysqli_ston"] = mysqli_connect("localhost","root","","blog_admin_db"));  //host,user,password,database
?>
